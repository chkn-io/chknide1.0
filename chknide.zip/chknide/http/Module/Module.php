<?php
class Module extends Controller{
	
}